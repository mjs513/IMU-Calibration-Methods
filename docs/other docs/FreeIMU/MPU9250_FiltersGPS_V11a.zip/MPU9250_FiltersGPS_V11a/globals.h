///////////////////////////////////////////////////////////////////////////////////////
// 
// Global Variables
///////////////////////////////////////////////////////////////////////////////////////
uint8_t passThrough_toggle;
int32_t incMissed;

//=============================

float q[4], ypr[3], _dt;
float grx, gry, grz;
float magHead;

float ax1, ay1, az1;
float gx1, gy1, gz1;
float mx1, my1, mz1;

// NED accel values
float aNEDx1, aNEDy1, aNEDz1;

//trig conversions
float rad2deg = 180.0f/PI;
float deg2rad = PI/180.0f;

//double utcTime, prevUTCtime, prevUtcTime;
double prevUTCtime, prevUtcTime;
float utcTime;

// Magnetic declination. If used, must be selected for your location.
// Note: May not be used in this sketch yet, needs to be checked.
//#define MAG_DEC -13.1603      //degrees for Flushing, NY
#define MAG_DEC 0

//standard gravity in m/s/s
#define gravConst  9.80665

unsigned long lastUpdate, now;  // sample period expressed in milliseconds

// a flag for when the MPU-9250 has new data
// a flag for when the MPU-9250 has new data
volatile int newIMUData;
volatile int newData_time;

// EEPROM buffer and variables to load accel and mag bias 
// and scale factors from CalibrateMPU9250.ino
uint8_t EepromBuffer[48];
float a_xb, a_xs, a_yb, a_ys, a_zb, a_zs;
float hxb, hxs, hyb, hys, hzb, hzs;

// timers to measure performance
unsigned long tstart, tstop;
  
elapsedMillis sincePrint;
elapsedMicros timeStamp;
elapsedMicros tsIMU;
volatile uint32_t IMU_RX_time = 0;
elapsedMicros tsGPS;
volatile uint32_t GPS_RX_time = 0;
uint32_t GPSrxs=0; // bugbug debug


int led = 13;

bool imuDataRdy = false;
volatile int GPS_newData;

struct GPS {
  unsigned long     iTOW;      ///< [ms], GPS time of the navigation epoch
  int32_t             ts;
  int32_t          tsOld;
  unsigned char  fixType;      ///< [ND], GNSSfix Type: 0: no fix, 1: dead reckoning only, 
                               ///< 2: 2D-fix, 3: 3D-fix, 4: GNSS + dead reckoning combined, 
                               ///< 5: time only fix
  unsigned char    numSV;      ///< [ND], Number of satellites used in Nav Solution
  double            lon1;      ///< [deg], Longitude
  double            lat1;      ///< [deg], Latitude
  double            hMSL;      ///< [m], Height above mean sea level
  double            velN;      ///< [m/s], NED north velocity
  double            velE;      ///< [m/s], NED east velocity
  double            velD;      ///< [m/s], NED down velocity
  double          gSpeed;      ///< [m/s], Ground Speed (2-D)
  double         heading;      ///< [deg], Heading of motion (2-D)
  double            pDOP;      ///< [ND], Position DOP
  double         utcTime;      ///  composit utc time
  bool           upDated;      ///  flag for GPS data updated
} rtk;

//==========================================================
// helper functions
// Inverse square root function for MARG Fileter (Madgwick and Mahoney)
float invSqrt(float x) {
        int instability_fix = 1;
        if (instability_fix == 0)
        {
             union {
               float f;
               int32_t i;
               } y;

             y.f = x;
             y.i = 0x5f375a86 - (y.i >> 1);
             y.f = y.f * ( 1.5f - ( x * 0.5f * y.f * y.f ) );
             return y.f;
        }
        else if (instability_fix == 1)
        {
                /* close-to-optimal  method with low cost from
        http://pizer.wordpress.com/2008/10/12/fast-inverse-square-root */
                uint32_t i = 0x5F1F1412 - (*(uint32_t*)&x >> 1);
                float tmp = *(float*)&i;
                return tmp * (1.69000231f - 0.714158168f * x * tmp * tmp);
        }
        else
        {
                /* optimal but expensive method: */
                return 1.0f / sqrt(x);
        }
}


/**
 * Converts a 3 elements array arr of angles expressed in radians into degrees
*/
void arr3_rad_to_deg(float * arr) {
  arr[0] *= 180/PI;
  arr[1] *= 180/PI;
  arr[2] *= 180/PI;
}

/**
 * Converts a 3 elements array arr of angles expressed in degrees into radians
*/
void arr3_deg_to_rad(float * arr) {
  arr[0] /= 180/PI;
  arr[1] /= 180/PI;
  arr[2] /= 180/PI;
}

/**
 * Returns the yaw pitch and roll angles, respectively defined as the angles in radians between
 * the Earth North and the IMU X a_xis (yaw), the Earth ground plane and the IMU X a_xis (pitch)
 * and the Earth ground plane and the IMU Y a_xis.
 * 
 * @note This is not an Euler representation: the rotations aren't consecutive rotations but only
 * angles from Earth and the IMU. For Euler representation Yaw, Pitch and Roll see FreeIMU::getEuler
 * 
 * @param ypr three floats array which will be populated by Yaw, Pitch and Roll angles in radians
*/
void getYawPitchRollRad(float * ypr) {
  //float grx, gry, grz; // estimated gravity direction
  
  //grx = 2 * (q[1]*q[3] - q[0]*q[2]);
  //gry = 2 * (q[0]*q[1] + q[2]*q[3]);
  //grz = q[0]*q[0] - q[1]*q[1] - q[2]*q[2] + q[3]*q[3];
  //calculate direction of gravity
  grx = 2 * (-q[1]*q[3] + q[0]*q[2]);
  gry = 2 * (-q[0]*q[1] - q[2]*q[3]);
  grz = -q[0]*q[0] + q[1]*q[1] + q[2]*q[2] - q[3]*q[3];

  ypr[0] = -atan2f(2 * q[1] * q[2] - 2 * q[0] * q[3], 2 * q[0]*q[0] + 2 * q[1] * q[1] - 1);
  ypr[1] = -atanf(grx / sqrt(gry*gry + grz*grz));
  ypr[2] = atanf(gry / sqrt(grx*grx + grz*grz));
}

/**
 * Returns the yaw pitch and roll angles, respectively defined as the angles in degrees between
 * the Earth North and the IMU X a_xis (yaw), the Earth ground plane and the IMU X a_xis (pitch)
 * and the Earth ground plane and the IMU Y a_xis.
 * 
 * @note This is not an Euler representation: the rotations aren't consecutive rotations but only
 * angles from Earth and the IMU. For Euler representation Yaw, Pitch and Roll see FreeIMU::getEuler
 * 
 * @param ypr three floats arra_y which will be populated by Yaw, Pitch and Roll angles in degrees
*/
void getYawPitchRoll(float * ypr) {
  getYawPitchRollRad(ypr);
  arr3_rad_to_deg(ypr);
}

/**
 * Returns the Euler angles in radians defined in the Aerospace sequence.
 * See Sebastian O.H. Madwick report "An efficient orientation filter for 
 * inertial and intertial/magnetic sensor arra_ys" Chapter 2 Quaternion representation
 * 
 * @param angles three floats arra_y which will be populated by the Euler angles in radians
*/
void getEulerRad(float * angles) {
  float a12, a22, a31, a32, a33;
  //angles[0] = atan2(2 * q[1] * q[2] - 2 * q[0] * q[3], 2 * q[0]*q[0] + 2 * q[1] * q[1] - 1); // psi
  //angles[1] = -asin(2 * q[1] * q[3] + 2 * q[0] * q[2]); // theta
  //angles[2] = atan2(2 * q[2] * q[3] - 2 * q[0] * q[1], 2 * q[0] * q[0] + 2 * q[3] * q[3] - 1); // phi

    a12 =   2.0f * (q[1] * q[2] + q[0] * q[3]);
    a22 =   q[0] * q[0] + q[1] * q[1] - q[2] * q[2] - q[3] * q[3];
    a31 =   2.0f * (q[0] * q[1] + q[2] * q[3]);
    a32 =   2.0f * (q[1] * q[3] - q[0] * q[2]);
    a33 =   q[0] * q[0] - q[1] * q[1] - q[2] * q[2] + q[3] * q[3];
    angles[1] = -asinf(a32);
    angles[2]  = atan2f(a31, a33);
    angles[0]   = atan2f(a12, a22);
}

/**
 * Returns the Euler angles in degrees defined with the Aerospace sequence (NED).  Conversion
 * based on MATLAB quat2angle.m for an ZXY rotation sequence.
 * Angles are lie between 0-360 degrees in radians.
 * 
 * @param angles three floats arra_y which will be populated by the Euler angles in degrees
*/
void getEuler360(float * angles) {
  getEulerRad(angles);
  arr3_deg_to_rad(angles);
}

/**
 * Returns the Euler angles in degrees defined with the Aerospace sequence.
 * See Sebastian O.H. Madwick report "An efficient orientation filter for 
 * inertial and intertial/magnetic sensor arra_ys" Chapter 2 Quaternion representation
 * 
 * @param angles three floats arra_y which will be populated by the Euler angles in degrees
*/
void getEuler(float * angles) {
  getEulerRad(angles);
  arr3_rad_to_deg(angles);
}

/**
 * Get heading from magnetometer if LSM303 not available
 * code extracted from rob42/FreeIMU-20121106_1323 Github library
 * (https://github.com/rob42/FreeIMU-20121106_1323.git)
 * which is based on 
 *
**/
float calcMagHeading(float q0, float q1, float q2, float q3, float bx, float by, float bz){
  float Head_X, Head_Y;
  float cos_roll, sin_roll, cos_pitch, sin_pitch;
  float grx, gry, grz; // estimated gravity direction
  float ypr[3];
  
  //grx = 2 * (q1*q3 - q0*q2);
  //gry = 2 * (q0*q1 + q2*q3);
  //grz = q0*q0 - q1*q1 - q2*q2 + q3*q3;
  grx = 2 * (-q[1]*q[3] + q[0]*q[2]);
  gry = 2 * (-q[0]*q[1] - q[2]*q[3]);
  grz = -q[0]*q[0] + q[1]*q[1] + q[2]*q[2] - q[3]*q[3];
  
  ypr[0] = -atan2f(2 * q1 * q2 - 2 * q0 * q3, 2 * q0*q0 + 2 * q1 * q1 - 1);
  ypr[1] = -atanf(grx / sqrt(gry*gry + grz*grz));
  ypr[2] = atanf(gry / sqrt(grx*grx + grz*grz)); 

  cos_roll = cosf(-ypr[2]);
  sin_roll = sinf(-ypr[2]);
  cos_pitch = cosf(ypr[1]);
  sin_pitch = sinf(ypr[1]);
  
  //Example calc
  //Xh = bx * cos(theta) + by * sin(phi) * sin(theta) + bz * cos(phi) * sin(theta)
  //Yh = by * cos(phi) - bz * sin(phi)
  //return wrap((atan2(-Yh, Xh) + variation))
  // Tilt compensated Magnetic field X component:
  Head_X = bx*cos_pitch + by*sin_roll*sin_pitch + bz*cos_roll*sin_pitch;
  // Tilt compensated Magnetic field Y component:
  Head_Y = by*cos_roll - bz*sin_roll;
  // Magnetic Heading
  return (atan2f(-Head_Y,Head_X)*180./PI) + MAG_DEC;
}

