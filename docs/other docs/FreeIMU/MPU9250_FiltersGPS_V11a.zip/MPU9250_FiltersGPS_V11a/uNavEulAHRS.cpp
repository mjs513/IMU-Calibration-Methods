///////////////////////////////////////////////////////////////////////////////////////
// 
// Implementation of 3-State EKF AHRS Algorithm
///////////////////////////////////////////////////////////////////////////////////////

/*
uNavAHRS.cpp
Brian R Taylor
brian.taylor@bolderflight.com
Bolder Flight Systems
Copyright 2017 Bolder Flight Systems

Permission is hereby granted, free of charge, to any person obtaining a copy of this software 
and associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, 
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or 
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING 
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include "Arduino.h"
#include "uNavEulAHRS.h"

/* sets the duration for gathering IMU statistics, us */
void uNavAHRS::setInitializationDuration(uint32_t duration) {
  _duration = duration;
}

// time and measurement update for uNavAHRS
// gx, gy, gz input in rad/s
// ax, ay, az input in consistant units
// hx, hy, hz input in consistant units
bool uNavAHRS::update(float gx,float gy,float gz,float ax,float ay,float az,float hx, float hy, float hz) {

  // checking if gyro data updated
  if ((gx!=gx_)||(gy!=gy_)||(gz!=gz_)) {
    gyroUpdated_ = true;
    gx_ = gx;
    gy_ = gy;
    gz_ = gz;
  } else {
    gyroUpdated_ = false;
  }

  // checking if accel data updated
  if ((ax!=ax_)||(ay!=ay_)||(az!=az_)) {
    accelUpdated_ = true;
    ax_ = ax;
    ay_ = ay;
    az_ = az;
  } else {
    accelUpdated_ = false;
  }

  // checking if magnetometer data updated
  if ((hx!=hx_)||(hy!=hy_)||(hz!=hz_)) {
    magUpdated_ = true;
    hx_ = hx;
    hy_ = hy;
    hz_ = hz;
  } else {
    magUpdated_ = false;
  }

  if (!_initialized) {
    /* gather sensor statistics */
    if (!_timeLatch) {
      _startingTime = micros();
      _timeLatch = true;
    }
    if ((micros() - _startingTime) < _duration) {
      // Welfords algorithm for mean and variance

      if (gyroUpdated_) {
        _gyroCount++;
        _gyroDelta(0,0) = gx - _gyroBias(0,0);
        _gyroBias(0,0) = _gyroBias(0,0) + _gyroDelta(0,0) / ((float)_gyroCount);
        _gyroDelta2(0,0) = gx - _gyroBias(0,0);
        _gyroM2(0,0) = _gyroM2(0,0) + _gyroDelta(0,0) * _gyroDelta2(0,0);
        _gyroDelta(1,0) = gy - _gyroBias(1,0);
        _gyroBias(1,0) = _gyroBias(1,0) + _gyroDelta(1,0) / ((float)_gyroCount);
        _gyroDelta2(1,0) = gy - _gyroBias(1,0);
        _gyroM2(1,0) = _gyroM2(1,0) + _gyroDelta(1,0) * _gyroDelta2(1,0);
        _gyroDelta(2,0) = gz - _gyroBias(2,0);
        _gyroBias(2,0) = _gyroBias(2,0) + _gyroDelta(2,0) / ((float)_gyroCount);
        _gyroDelta2(2,0) = gz - _gyroBias(2,0);
        _gyroM2(2,0) = _gyroM2(2,0) + _gyroDelta(2,0) * _gyroDelta2(2,0);
        if (_gyroCount > 2) {
          _gyroVariance(0,0) = _gyroM2(0,0)/((float)(_gyroCount-1));
          _gyroVariance(1,0) = _gyroM2(1,0)/((float)(_gyroCount-1));
          _gyroVariance(2,0) = _gyroM2(2,0)/((float)(_gyroCount-1));
        }
      }

      if (accelUpdated_) {
        _accelCount++;
        _accelDelta(0,0) = ax - _accelMean(0,0);
        _accelMean(0,0) = _accelMean(0,0) + _accelDelta(0,0) / ((float)_accelCount);
        _accelDelta2(0,0) = ax - _accelMean(0,0);
        _accelM2(0,0) = _accelM2(0,0) + _accelDelta(0,0) * _accelDelta2(0,0);
        _accelDelta(1,0) = ay - _accelMean(1,0);
        _accelMean(1,0) = _accelMean(1,0) + _accelDelta(1,0) / ((float)_accelCount);
        _accelDelta2(1,0) = ay - _accelMean(1,0);
        _accelM2(1,0) = _accelM2(1,0) + _accelDelta(1,0) * _accelDelta2(1,0);
        _accelDelta(2,0) = az - _accelMean(2,0);
        _accelMean(2,0) = _accelMean(2,0) + _accelDelta(2,0) / ((float)_accelCount);
        _accelDelta2(2,0) = az - _accelMean(2,0);
        _accelM2(2,0) = _accelM2(2,0) + _accelDelta(2,0) * _accelDelta2(2,0);
        if (_accelCount > 2) {
          _accelVariance(0,0) = _accelM2(0,0)/((float)(_accelCount-1));
          _accelVariance(1,0) = _accelM2(1,0)/((float)(_accelCount-1));
          _accelVariance(2,0) = _accelM2(2,0)/((float)(_accelCount-1));
        }
      }

      if (magUpdated_) {
        _magCount++;
        _magDelta(0,0) = hx - _magMean(0,0);
        _magMean(0,0) = _magMean(0,0) + _magDelta(0,0) / ((float)_magCount);
        _magDelta2(0,0) = hx - _magMean(0,0);
        _magM2(0,0) = _magM2(0,0) + _magDelta(0,0) * _magDelta2(0,0);
        _magDelta(1,0) = hy - _magMean(1,0);
        _magMean(1,0) = _magMean(1,0) + _magDelta(1,0) / ((float)_magCount);
        _magDelta2(1,0) = hy - _magMean(1,0);
        _magM2(1,0) = _magM2(1,0) + _magDelta(1,0) * _magDelta2(1,0);
        _magDelta(2,0) = hz - _magMean(2,0);
        _magMean(2,0) = _magMean(2,0) + _magDelta(2,0) / ((float)_magCount);
        _magDelta2(2,0) = hz - _magMean(2,0);
        _magM2(2,0) = _magM2(2,0) + _magDelta(2,0) * _magDelta2(2,0);
        if (_magCount > 2) {
          _magVariance(0,0) = _magM2(0,0)/((float)(_magCount-1));
          _magVariance(1,0) = _magM2(1,0)/((float)(_magCount-1));
          _magVariance(2,0) = _magM2(2,0)/((float)(_magCount-1));
        }
      }

      if ((accelUpdated_)&&(magUpdated_)) {
        _EulerCount++;
        // estimate the Euler angles to get an idea of the initial state covariance
        _accel(0,0) = ax;
        _accel(1,0) = ay;
        _accel(2,0) = az;
        _mag(0,0) = hx;
        _mag(1,0) = hy;
        _mag(2,0) = hz;
        _accel.normalize();
        _mag.normalize();
        _Euler(1,0) = asin(_accel(0,0));
        _Euler(0,0) = asin(-_accel(1,0)/(cos(_Euler(1,0))));
        _Euler(2,0) = atan2(_mag(2,0)*sin(_Euler(0,0))-_mag(1,0)*cos(_Euler(0,0)),_mag(0,0)*cos(_Euler(1,0))+_mag(1,0)*sin(_Euler(1,0))*sin(_Euler(0,0))+_mag(2,0)*sin(_Euler(1,0))*cos(_Euler(0,0)));
        _EulerDelta(0,0) = _Euler(0,0) - _EulerMean(0,0);
        _EulerMean(0,0) = _EulerMean(0,0) + _EulerDelta(0,0) / ((float)_EulerCount);
        _EulerDelta2(0,0) = _Euler(0,0) - _EulerMean(0,0);
        _EulerM2(0,0) = _EulerM2(0,0) + _EulerDelta(0,0) * _EulerDelta2(0,0);
        _EulerDelta(1,0) = _Euler(1,0) - _EulerMean(1,0);
        _EulerMean(1,0) = _EulerMean(1,0) + _EulerDelta(1,0) / ((float)_EulerCount);
        _EulerDelta2(1,0) = _Euler(1,0) - _EulerMean(1,0);
        _EulerM2(1,0) = _EulerM2(1,0) + _EulerDelta(1,0) * _EulerDelta2(1,0);
        _EulerDelta(2,0) = _Euler(2,0) - _EulerMean(2,0);
        _EulerMean(2,0) = _EulerMean(2,0) + _EulerDelta(2,0) / ((float)_EulerCount);
        _EulerDelta2(2,0) = _Euler(2,0) - _EulerMean(2,0);
        _EulerM2(2,0) = _EulerM2(2,0) + _EulerDelta(2,0) * _EulerDelta2(2,0);
        if (_EulerCount > 2) {
          _EulerVariance(0,0) = _EulerM2(0,0)/((float)(_EulerCount-1));
          _EulerVariance(1,0) = _EulerM2(1,0)/((float)(_EulerCount-1));
          _EulerVariance(2,0) = _EulerM2(2,0)/((float)(_EulerCount-1));
        }
      }
    } else {

      /* initialize state */
      x_(0,0) = _EulerMean(0,0);
      x_(1,0) = _EulerMean(1,0);
      xh_(0,0) = _EulerMean(2,0);
      yh_(0,0) = _EulerMean(2,0);
      _initialEuler = _EulerMean;

      /* initialize process covariance */
      P_(0,0) = _EulerVariance(0,0);
      P_(1,1) = _EulerVariance(1,0);
      Ph_(0,0) = _EulerVariance(2,0);

      /* initialize gyro covariance matrix */
      Q_(0,0) = _gyroVariance(0,0);
      Q_(1,1) = _gyroVariance(1,0);
      Q_(2,2) = _gyroVariance(2,0);
      Q_ = Q_ + 0.0002*Eigen::Matrix<float,3,3>::Identity();

      /* initialize measurement covariance matrix */
      Ra_(0,0) = _accelVariance(0,0);
      Ra_(1,1) = _accelVariance(1,0);
      Ra_(2,2) = _accelVariance(2,0);
      Rh_(0,0) = _EulerVariance(2,0);

      /* initialize the time */
      _t = 0;

      /* initialization complete */
      _initialized = true;
    }
  } else {

    /* time update */
    if (gyroUpdated_) {
      // get the change in time
      _dt = (float)_t /1000000.0;
      _t = 0;
      
      // rename gyros for ease of notation
      p = gx;
      q = gy;
      r = gz;

      /*********************************/
      /*** First stage Kalman filter ***/
      /*********************************/

      // rename states for ease of notation
      phi = x_(0,0);
      theta = x_(1,0);

      // state transition matrix
      F_(0,0) = 1.0+(q*cosf(phi)*tanf(theta)-r*sinf(phi)*tanf(theta))*_dt;
      F_(0,1) = (q*sinf(phi)/cosf(theta)/cosf(theta)+r*cosf(phi)/cosf(theta)/cosf(theta))*_dt;
      F_(1,0) = (-q*sinf(phi)-r*cosf(phi))*_dt;
      F_(1,1) = 1.0;
      // process noise matrix
      L_(0,0) = _dt;  L_(0,1) = _dt*sinf(phi)*tanf(theta);  L_(0,2) = _dt*cosf(phi)*tanf(theta);
      L_(1,0) = 0.0;  L_(1,1) = _dt*cosf(phi);              L_(1,2) = -_dt*sinf(phi);
      // covariance
      P_ = F_*P_*F_.transpose() + L_*Q_*L_.transpose();
      // propagate the state
      phi = phi+(p+q*sinf(phi)*tanf(theta)+r*cosf(phi)*tanf(theta))*_dt;
      theta = theta+(q*cosf(phi)-r*sinf(phi))*_dt;
      x_(0,0) = phi;
      x_(1,0) = theta;
      
      /* accel measurement update */
      if (accelUpdated_) {
        phi = x_(0,0);
        theta = x_(1,0);
        _accel(0,0) = ax;
        _accel(1,0) = ay;
        _accel(2,0) = az;
        _accel.normalize();
        // measurement jacobian
        Ha_(0,0) = 0.0;                     Ha_(0,1) = cosf(theta);           
        Ha_(1,0) = -cosf(theta)*cosf(phi);  Ha_(1,1) = sinf(theta)*sinf(phi); 
        Ha_(2,0) = cosf(theta)*sinf(phi);   Ha_(2,1) = sinf(theta)*cosf(phi); 
        // kalman gain
        Ka_ = P_*Ha_.transpose()*(Ha_*P_*Ha_.transpose()+Ra_).inverse();
        // estimated output
        ha_(0,0) = sinf(theta);
        ha_(1,0) = -cosf(theta)*sinf(phi);
        ha_(2,0) = -cosf(theta)*cosf(phi);
        // measured output
        ya_(0,0) = _accel(0,0);
        ya_(1,0) = _accel(1,0);
        ya_(2,0) = _accel(2,0);
        // state
        x_ = x_ + Ka_*(ya_-ha_);
        // covariance
        P_ = (Eigen::Matrix<float,2,2>::Identity()-Ka_*Ha_)*P_;
      }

      /**********************************/
      /*** Second stage Kalman filter ***/
      /**********************************/

      // rename states for ease of notation
      phi = x_(0,0);
      theta = x_(1,0);
      psi = xh_(0,0);

      // state transition matrix
      Fh_(0,0) = 1.0f;
      // process noise matrix
      Lh_(0,0) = 0.0;  Lh_(0,1) = _dt*sinf(phi)/cosf(theta);  Lh_(0,2) = _dt*cosf(phi)/cosf(theta);
      // covariance
      Ph_ = Fh_*Ph_*Fh_.transpose() + Lh_*Q_*Lh_.transpose();
      // propagate the state
      psi = psi + (q*sinf(phi)/cosf(theta)+r*cosf(phi)/cosf(theta))*_dt;
      xh_(0,0) = psi;

      /* magnetometer measurement update */
      if (magUpdated_) {
        phi = x_(0,0);
        theta = x_(1,0);
        psi = xh_(0,0);
        _mag(0,0) = hx;
        _mag(1,0) = hy;
        _mag(2,0) = hz;
        _mag.normalize();
        // measurement jacobian
        Hh_(0,0) = 1.0;
        // kalman gain
        Kh_ = Ph_*Hh_.transpose()*(Hh_*Ph_*Hh_.transpose()+Rh_).inverse();
        // estimated output
        hh_(0,0) = psi;
        // measured output
        prevPsi = yh_(0,0);
        yh_(0,0) = atan2f(_mag(2,0)*sinf(phi)-_mag(1,0)*cosf(phi),_mag(0,0)*cosf(theta)+_mag(1,0)*sinf(theta)*sinf(phi)+_mag(2,0)*sinf(theta)*cosf(phi));
        yh_(0,0) = unwrap(prevPsi, yh_(0,0));
        // state
        xh_ = xh_ + Kh_*(yh_-hh_);
        // covariance
        Ph_ = (Eigen::Matrix<float,1,1>::Identity()-Kh_*Hh_)*Ph_;
      }
    }
  }

  if (_initialized) {
    return true;
  } else {
    return false;
  }
}

/* Returns the roll angle, rad */
float uNavAHRS::getRoll_rad() {
  return ((constrainAngle180(x_(0,0))));
}

/* Returns the pitch angle, rad */
float uNavAHRS::getPitch_rad() {
  return (x_(1,0));  
}

/* Returns the yaw angle, rad */
float uNavAHRS::getYaw_rad() {
  float wrappedAngle;
  wrappedAngle = constrainAngle180(xh_(0,0));
  return (constrainAngle180(wrappedAngle-_initialEuler(2,0))); 
}

/* Returns the heading angle, rad */
float uNavAHRS::getHeading_rad() {
  return (constrainAngle360(constrainAngle180(xh_(0,0)))); 
}

/* Returns the unwrapped angle */
float uNavAHRS::unwrap(float prevAngle, float newAngle) {
  return prevAngle - angleDiff(newAngle,prevAngle);
}

/* Returns the difference between two angles */
float uNavAHRS::angleDiff(float dta, float dtb) {
  float diff;
  diff = fmod(dtb-dta+PI,PI*2.0);
  if (diff < 0.0) {
    diff += PI*2.0;
  }
  return diff - PI;
}

/* Bound angle between -180 and 180 */
float uNavAHRS::constrainAngle180(float dta) {
  while(dta >  PI) dta -= (PI*2.0);
  while(dta < -PI) dta += (PI*2.0);
  return dta;
}

/* Bound angle between 0 and 360 */
float uNavAHRS::constrainAngle360(float dta) {
  dta = fmod(dta,2.0*PI);
  if (dta < 0.0)
    dta += 2.0*PI;
  return dta;
}
